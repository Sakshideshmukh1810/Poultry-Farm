﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Poultry_farm
{
    public partial class BankDetail : Form
    {
        User db = new User();
        public BankDetail()
        {
            InitializeComponent();
        }

        private void BankDetail_Load(object sender, EventArgs e)
        {
            db.FillGridData(bankgridv, "Select *from tblbank");
            btnnew.Focus();
            EnabledFales();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
            mainform fr = new mainform();

            fr.Show();
        }
        void EnabledFales()
        {
            btnsave.Enabled = false;
            btnupdate.Enabled = false;
            btnclose.Enabled = true;

        }
        void cleadata()
        {
            txtid.Clear();
            txtob.Clear();
            txtano.Clear();
            txtaddress.Clear();
            txtibno.Clear();
            txtname.Clear();
        }
        
        void GetmaxID()
        {
            txtid.Text = db.GetAutoId("Select Max(BankID) from tblbank").ToString();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == ""|| txtaddress.Text == ""|| txtibno.Text == ""||txtano.Text == ""||txtob.Text == "")
            {
                MessageBox.Show("Missing Fields");
                return;
            }

            db.ExecuteSqlQuery("Insert into  tblbank(BankID,BankName,Address,IBAN,AccountNumber,OpeningBalance)Values('" + txtid.Text + "','" + txtname.Text + "','" + txtaddress.Text + "','" + txtibno.Text + "','" + txtano.Text + "','" + txtob.Text+ "')");
            cleadata();

            btnnew.Focus();
            db.FillGridData(bankgridv, "Select *from tblbank");

            MessageBox.Show("saved successfully");
        }
        void Griddisplay()
        {
            try
            {
                txtid.Text = bankgridv.SelectedRows[0].Cells["BankID"].Value.ToString();
                txtname.Text = bankgridv.SelectedRows[0].Cells["BankName"].Value.ToString();
                txtaddress.Text = bankgridv.SelectedRows[0].Cells["Address"].Value.ToString();
                txtibno.Text = bankgridv.SelectedRows[0].Cells["IBAN"].Value.ToString();
                txtano.Text = bankgridv.SelectedRows[0].Cells["AccountNumber"].Value.ToString();
                txtob.Text = bankgridv.SelectedRows[0].Cells["OpeningBalance"].Value.ToString();
                
                EnabledFales();
                btnupdate.Enabled = true;
               
                txtname.Focus();
            }
            catch { }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            if (txtid.Text == "" || txtname.Text == "" || txtaddress.Text == "" || txtibno.Text == "" || txtano.Text == "" || txtob.Text == "")
            {
                MessageBox.Show("Missing Fields");
                return;
            }

            db.ExecuteSqlQuery("Update tblbank SET BankName='" + txtname.Text + "',Address='" + txtaddress.Text + "',IBAN='" + txtibno.Text + "',AccountNumber='" + txtano.Text +"',OpeningBalance='"+txtob.Text + "' where BankID=" + txtid.Text);
            db.FillGridData(bankgridv, "Select * from tblbank");
            EnabledFales();
            cleadata();
            btnnew.Focus();
            MessageBox.Show("Update Data successfully");
        }

        private void bankgridv_MouseClick(object sender, MouseEventArgs e)
        {
            Griddisplay(); 
        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtname.Focus();
            btnsave.Enabled = true;
            GetmaxID();
        }

        private void txtano_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 8 || e.KeyChar == ' ' || char.IsDigit(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void txtob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 8 || e.KeyChar == ' ' || char.IsDigit(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

    }
}
