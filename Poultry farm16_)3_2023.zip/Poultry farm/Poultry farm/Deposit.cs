﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Poultry_farm
{
    public partial class Deposit : Form
    {
        User db = new User();
        public Deposit()
        {
            InitializeComponent();
        }

        private void Deposit_Load(object sender, EventArgs e)
        {
            db.FillCombo(cmbbank, "Select * from tblbank", "BankName", "OpeningBalance");
            btnnew.Focus();
            EnabledFales();
        }
        void EnabledFales()
        {
            btndeposit.Enabled = true;
            
            btnclose.Enabled = true;

        }
        void cleadata()
        {
            txtdamount.Clear();
            txtremark.Clear();
            
        }


        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
            mainform fr = new mainform();

            fr.Show();
        }

        private void cmbbank_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                
                txtbalance.Text = cmbbank.SelectedValue.ToString();
                DataTable dt = db.GettableData("Select *from tblbank where BankID=" + txtid.Text);
                if (dt.Rows.Count >= 1)
                {
                    txtbalance.Text = dt.Rows[0]["OpeningBalance"].ToString();
                    //txtcreditamt.Text=dt.Rows[0]["OBal"].ToString();
                }
            }
            catch
            {


            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

           


        }

        private void btndeposit_Click(object sender, EventArgs e)
        {

            if (cmbbank.Text == "" || txtbalance.Text == "" || txtdamount.Text == "" || txtdate.Text == "" || txtremark.Text == "" )
            {
                MessageBox.Show("Missing fields ");
                return;
            }
            if (MessageBox.Show("Do you want to deposit amount ?", "Deposit amount", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Process.Start("");
            }
            db.ExecuteSqlQuery("Insert into  tbldeposit(BankName,AvailableBalance,DepositAmount,Remark,Date)Values('" + cmbbank.Text + "','" + txtbalance.Text + "','" + txtdamount.Text + "','" + txtremark.Text + "','" + txtdate.Value.ToString("MM/dd/yyyy") + "')");
            cleadata();

            btnnew.Focus();
            

            MessageBox.Show("saved successfully");

        }

        private void btnnew_Click(object sender, EventArgs e)
        {

            

        }
        public void cal()
        {
            try
            {
                double a = 0;
                double b = 0;
                double c = 0;


                 if (txtbalance.Text != "")
                {
                    a = (float)Convert.ToDouble(txtbalance.Text);
                }
                if (txtdamount.Text != "")
                {
                    b = (float)Convert.ToDouble(txtdamount.Text);
                }

                c= a+ b;
                txttotal.Text = c.ToString();
            }
            catch (Exception ex)
            {

                string msg = ex.Message;
            }


        }

        private void txtdamount_TextChanged(object sender, EventArgs e)
        {
            cal();
        }

        private void txttotal_TextChanged(object sender, EventArgs e)
        {
            db.ExecuteSqlQuery("Insert into  tbldeposit(AvailableBalance)Values('" + txttotal.Text + "')");
        }

        private void txtdamount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 8 || e.KeyChar == ' ' || char.IsDigit(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

    }
}
