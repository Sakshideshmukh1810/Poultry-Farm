﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Poultry_farm
{
    public partial class mainform : Form
    {
        User db = new User();
        public mainform()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            custlist.Show();

        }

        private void custlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (custlist.Text == "Add Customer")
            {
                custentry ct = new custentry();
                ct.Show();
                this.Hide();
            }
            
        }

        private void mainform_Load(object sender, EventArgs e)
        {
            banklist.Visible = false;
            custlist.Visible = false;
            chickenlist.Visible = false;
            expenselist.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            companyentry cm = new companyentry();
            cm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            medicinentry mc = new medicinentry();
            mc.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            feedentry fe = new feedentry();
            fe.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chickenlist.Show();
        }

        private void chickenlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chickenlist.Text == "Birdcost")
            {
                Birdcost br = new Birdcost();
                br.Show();
                this.Hide();
            }
            if (chickenlist.Text == "Purchase")
            {
                Purchaseentry pe = new Purchaseentry();
                pe.Show();
                this.Hide();
            }
            if (chickenlist.Text == "FCR")
            {
                Fcr fc = new Fcr();
                fc.Show();
                this.Hide();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            expenselist.Show();
        }

        private void expenselist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (expenselist.Text == "Add Expenses")
            {
                expensentry ex = new expensentry();
                ex.Show();
                this.Hide();
            }
            if (expenselist.Text == "Expense Category")
            {
                expensecategory ec = new expensecategory();
                ec.Show();
                this.Hide();
            }
        }

        private void banklist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (banklist.Text == "Bank Detail")
            {
                BankDetail bd = new BankDetail();
                bd.Show();
                this.Hide();
            }
            if (banklist.Text == "Deposit")
            {
                Deposit dp = new Deposit();
                dp.Show();
                this.Hide();
            }
            if (banklist.Text == "Debit")
            {
                Debit de = new Debit();
                de.Show();
                this.Hide();
            }
        }

        private void btnbank_Click(object sender, EventArgs e)
        {
            banklist.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
